#include <stdio.h>

int main()
{
    long long a,b,c,d,e;
    scanf("%lld%lld%lld%lld%lld",&a,&b,&c,&d,&e);
    printf("%lld",a+b+c+d+e);

    return 0;
}
